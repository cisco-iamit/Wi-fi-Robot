
# Imports
import webiopi

# Retrieve GPIO lib
GPIO = webiopi.GPIO

# -------------------------------------------------- #
# Constants definition                               #
# -------------------------------------------------- #

# Drive motor GPIOs
motorRdPin = 24  # H-Bridge 1
motorFdPin = 23 # H-Bridge 2
motorDrivePWM = 18 # H-Bridge ENA

# Stear motor GPIOs
motorRightPin = 22 # H-Bridge 3
motorLeftPin = 10 # H-Bridge 4
motorStearPWM = 17 # H-Bridge ENB

# -------------------------------------------------- #
# Convenient PWM Function                            #
# -------------------------------------------------- #

# Set the speed of motor
def set_speed(motorDriveSpeed):
GPIO.pulseRatio(motorDrivePWM, motorDriveSpeed)
GPIO.pulseRatio(motorStearPWM, motorDriveSpeed)


# -------------------------------------------------- #
# Drive Motor Functions                               #
# -------------------------------------------------- #

def drive_stop():
   GPIO.output(motorRdPin, GPIO.LOW)
   GPIO.output(motorFdPin, GPIO.LOW)

def drive_forward():
   GPIO.output(motorRdPin, GPIO.LOW)
   GPIO.output(motorFdPin, GPIO.HIGH)

def drive_backward():
   GPIO.output(motorRdPin, GPIO.HIGH)
   GPIO.output(motorFdPin, GPIO.LOW)

# -------------------------------------------------- #
# Stear Motor Functions                              #
# -------------------------------------------------- #
def stear_stop():
   GPIO.output(motorRightPin, GPIO.LOW)
   GPIO.output(motorLeftPin, GPIO.LOW)

def stear_left():
   GPIO.output(motorRightPin, GPIO.LOW)
   GPIO.output(motorLeftPin, GPIO.HIGH)

def stear_right():
   GPIO.output(motorRightPin, GPIO.HIGH)
   GPIO.output(motorLeftPin, GPIO.LOW)

# -------------------------------------------------- #
# Macro definition part                              #
# -------------------------------------------------- #

def go_forward():
   drive_forward()

def go_backward():
   drive_backward()


def forward_left():
   drive_forward()
   stear_left()

def forward_right():
   drive_forward()
   stear_right()

def reverse_left():
   drive_backward()
   stear_right()

def reverse_right():
   drive_backward()
   stear_left()

def stop():
   stear_stop()
   drive_stop()

# -------------------------------------------------- #
# Initialization part                                #
# -------------------------------------------------- #

motorDriveSpeed = 0
maxspeed = 30
minspeed = 0
acceleration = 0
speedstep = 5

def setmotorspeed(motorDriveSpeed, acceleration):
   if(acceleration > 0):
       go_forward()
       if(acceleration > maxspeed):
           acceleration = maxspeed
       motorDriveSpeed = acceleration
   elif(acceleration == 0):
       motorDriveSpeed = acceleration
       stop()
   elif(acceleration < (maxspeed *-1)):
       acceleration = (maxspeed * -1)
   else:
       go_backward()
       motorDriveSpeed = (acceleration * -1)
   motorDriveSpeed = check_motorpseed(motorDriveSpeed)

   return motorDriveSpeed, acceleration


#This function is used for forward movment
def forward(motorDriveSpeed):
   if(motorDriveSpeed < motorDriveSpeed):
       motorDriveSpeed = motorDriveSpeed + speedstep

   motorDriveSpeed = check_motorpseed(motorDriveSpeed)
   return motorDriveSpeed

def reverse(motorDriveSpeed):
   if(motorDriveSpeed < motorDriveSpeed):
       motorDriveSpeed = motorDriveSpeed - speedstep

   motorDriveSpeed = check_motorpseed(motorDriveSpeed)
   return motorDriveSpeed

# check the motorspeed if it is correct and in max/min range
def check_motorpseed(motorDriveSpeed):
   if (motorDriveSpeed < minspeed):
       motorDriveSpeed = minspeed

   if (motorDriveSpeed > maxspeed):
       motorDriveSpeed = maxspeed

   return motorDriveSpeed


# Setup GPIOs
GPIO.setFunction(motorDrivePWM, GPIO.PWM)
GPIO.setFunction(motorRdPin, GPIO.OUT)
GPIO.setFunction(motorFdPin, GPIO.OUT)

GPIO.setFunction(motorStearPWM, GPIO.PWM)
GPIO.setFunction(motorRightPin, GPIO.OUT)
GPIO.setFunction(motorLeftPin, GPIO.OUT)


set_speed(motorDriveSpeed)
stop()

# -------------------------------------------------- #
# Main server part                                   #
# -------------------------------------------------- #


# Instantiate the server on the port 8000, it starts immediately in its own thread
server = webiopi.Server(port=8000, login="picar", password="picar")

# Register the macros so you can call it with Javascript and/or REST API

server.addMacro(go_forward)
server.addMacro(go_backward)
server.addMacro(forward_left)
server.addMacro(forward_right)
server.addMacro(reverse_left)
server.addMacro(reverse_right)
server.addMacro(stop)

# -------------------------------------------------- #
# Loop execution part                                #
# -------------------------------------------------- #

# Run our loop until CTRL-C is pressed or SIGTERM received
webiopi.runLoop()

# -------------------------------------------------- #
# Termination part                                   #
# -------------------------------------------------- #

# Stop the server
server.stop()

# Reset GPIO functions
GPIO.setFunction(motorDrivePWM, GPIO.IN)
GPIO.setFunction(motorRdPin, GPIO.IN)
GPIO.setFunction(motorFdPin, GPIO.IN)

GPIO.setFunction(motorStearPWM, GPIO.IN)
GPIO.setFunction(motorRightPin, GPIO.IN)
GPIO.setFunction(motorLeftPin, GPIO.IN)
